var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// _worker.js
var e = /* @__PURE__ */ __name((e4, t3, n2) => (r2, i2) => {
  let a2 = -1;
  return o2(0);
  async function o2(s2) {
    if (s2 <= a2) throw Error(`next() called multiple times`);
    a2 = s2;
    let c2, l2 = false, u2;
    if (e4[s2] ? (u2 = e4[s2][0][0], r2.req.routeIndex = s2) : u2 = s2 === e4.length && i2 || void 0, u2) try {
      c2 = await u2(r2, () => o2(s2 + 1));
    } catch (e5) {
      if (e5 instanceof Error && t3) r2.error = e5, c2 = await t3(e5, r2), l2 = true;
      else throw e5;
    }
    else r2.finalized === false && n2 && (c2 = await n2(r2));
    return c2 && (r2.finalized === false || l2) && (r2.res = c2), r2;
  }
  __name(o2, "o");
}, "e");
var t = /* @__PURE__ */ Symbol();
var n = /* @__PURE__ */ __name((e4, t3) => new Response(e4, { headers: { "Content-Type": t3.replace(/^[^;]+/, (e5) => e5.toLowerCase()) } }).formData(), "n");
var r = 32;
var i = 1e4;
var a = /* @__PURE__ */ __name((e4) => `headers` in e4, "a");
var o = /* @__PURE__ */ __name(async (e4, t3 = /* @__PURE__ */ Object.create(null)) => {
  let { all: n2 = false, dot: r2 = false } = t3, i2 = (a(e4) ? e4.headers : e4.raw.headers).get(`Content-Type`)?.split(`;`)[0].trim().toLowerCase();
  return i2 === `multipart/form-data` || i2 === `application/x-www-form-urlencoded` ? s(e4, { all: n2, dot: r2 }) : {};
}, "o");
async function s(e4, t3) {
  if (!a(e4) && e4.bodyCache.formData) return c(await e4.bodyCache.formData, t3);
  let r2 = a(e4) ? e4.headers : e4.raw.headers, i2 = n(await e4.arrayBuffer(), r2.get(`Content-Type`) || ``);
  a(e4) || (e4.bodyCache.formData = i2);
  let o2 = await i2;
  return o2 ? c(o2, t3) : {};
}
__name(s, "s");
function c(e4, t3) {
  let n2 = /* @__PURE__ */ Object.create(null), r2 = { count: 0 };
  return e4.forEach((e5, r3) => {
    t3.all || r3.endsWith(`[]`) ? l(n2, r3, e5) : n2[r3] = e5;
  }), t3.dot && Object.entries(n2).forEach(([e5, t4]) => {
    e5.includes(`.`) && (u(n2, e5, t4, r2), delete n2[e5]);
  }), n2;
}
__name(c, "c");
var l = /* @__PURE__ */ __name((e4, t3, n2) => {
  e4[t3] === void 0 ? e4[t3] = t3.endsWith(`[]`) ? [n2] : n2 : Array.isArray(e4[t3]) ? e4[t3].push(n2) : e4[t3] = [e4[t3], n2];
}, "l");
var u = /* @__PURE__ */ __name((e4, t3, n2, a2) => {
  if (/(?:^|\.)__proto__\./.test(t3)) return;
  let o2 = e4, s2 = t3.split(`.`, r + 2);
  s2.length > r + 1 && d(), s2.forEach((e5, t4) => {
    t4 === s2.length - 1 ? o2[e5] = n2 : ((!o2[e5] || typeof o2[e5] != `object` || Array.isArray(o2[e5]) || o2[e5] instanceof File) && (a2.count++ >= i && d(), o2[e5] = /* @__PURE__ */ Object.create(null)), o2 = o2[e5]);
  });
}, "u");
var d = /* @__PURE__ */ __name(() => {
  throw Error(`Nesting limit exceeded`);
}, "d");
var f = /* @__PURE__ */ __name((e4) => {
  let t3 = e4.split(`/`);
  return t3[0] === `` && t3.shift(), t3;
}, "f");
var p = /* @__PURE__ */ __name((e4) => {
  let { groups: t3, path: n2 } = m(e4);
  return h(f(n2), t3);
}, "p");
var m = /* @__PURE__ */ __name((e4) => {
  let t3 = [];
  return e4 = e4.replace(/\{[^}]+\}/g, (e5, n2) => {
    let r2 = `@${n2}`;
    return t3.push([r2, e5]), r2;
  }), { groups: t3, path: e4 };
}, "m");
var h = /* @__PURE__ */ __name((e4, t3) => {
  for (let n2 = t3.length - 1; n2 >= 0; n2--) {
    let [r2] = t3[n2];
    for (let i2 = e4.length - 1; i2 >= 0; i2--) if (e4[i2].includes(r2)) {
      e4[i2] = e4[i2].replace(r2, t3[n2][1]);
      break;
    }
  }
  return e4;
}, "h");
var g = {};
var ee = /* @__PURE__ */ __name((e4, t3) => {
  if (e4 === `*`) return `*`;
  let n2 = e4.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (n2) {
    let r2 = `${e4}#${t3}`;
    return g[r2] || (g[r2] = n2[2] ? t3 && t3[0] !== `:` && t3[0] !== `*` ? [r2, n2[1], RegExp(`^${n2[2]}(?=/${t3})`)] : [e4, n2[1], RegExp(`^${n2[2]}$`)] : [e4, n2[1], true]), g[r2];
  }
  return null;
}, "ee");
var _ = /* @__PURE__ */ __name((e4, t3) => {
  try {
    return t3(e4);
  } catch {
    return e4.replace(/(?:%[0-9A-Fa-f]{2})+/g, (e5) => {
      try {
        return t3(e5);
      } catch {
        return e5;
      }
    });
  }
}, "_");
var te = /* @__PURE__ */ __name((e4) => _(e4, decodeURI), "te");
var v = /* @__PURE__ */ __name((e4) => {
  let t3 = e4.url, n2 = t3.indexOf(`/`, t3.indexOf(`:`) + 4), r2 = n2;
  for (; r2 < t3.length; r2++) {
    let e5 = t3.charCodeAt(r2);
    if (e5 === 37) {
      let e6 = t3.indexOf(`?`, r2), i2 = t3.indexOf(`#`, r2), a2 = e6 === -1 ? i2 === -1 ? void 0 : i2 : i2 === -1 ? e6 : Math.min(e6, i2), o2 = t3.slice(n2, a2);
      return te(o2.includes(`%25`) ? o2.replace(/%25/g, `%2525`) : o2);
    }
    if (e5 === 63 || e5 === 35) break;
  }
  return t3.slice(n2, r2);
}, "v");
var ne = /* @__PURE__ */ __name((e4) => {
  let t3 = v(e4);
  return t3.length > 1 && t3.at(-1) === `/` ? t3.slice(0, -1) : t3;
}, "ne");
var y = /* @__PURE__ */ __name((e4, t3, ...n2) => (n2.length && (t3 = y(t3, ...n2)), `${e4?.[0] === `/` ? `` : `/`}${e4}${t3 === `/` ? `` : `${e4?.at(-1) === `/` ? `` : `/`}${t3?.[0] === `/` ? t3.slice(1) : t3}`}`), "y");
var b = /* @__PURE__ */ __name((e4) => {
  if (e4.charCodeAt(e4.length - 1) !== 63 || !e4.includes(`:`)) return null;
  let t3 = e4.split(`/`), n2 = [], r2 = ``;
  return t3.forEach((e5) => {
    if (e5 !== `` && !/\:/.test(e5)) r2 += `/` + e5;
    else if (/\:/.test(e5)) {
      if (e5.charCodeAt(e5.length - 1) === 63) {
        n2.length === 0 && r2 === `` ? n2.push(`/`) : n2.push(r2);
        let t4 = e5.slice(0, -1);
        r2 += `/` + t4, n2.push(r2);
      } else r2 += `/` + e5;
    }
  }), n2.filter((e5, t4, n3) => n3.indexOf(e5) === t4);
}, "b");
var x = /* @__PURE__ */ __name((e4) => e4.indexOf(`%`) === -1 ? e4 : _(e4, oe), "x");
var S = /* @__PURE__ */ __name((e4) => (e4.indexOf(`+`) !== -1 && (e4 = e4.replace(/\+/g, ` `)), x(e4)), "S");
var re = /* @__PURE__ */ __name((e4, t3, n2) => {
  let r2 = e4.indexOf(`#`, 8);
  r2 !== -1 && (e4 = e4.slice(0, r2));
  let i2;
  if (!n2 && t3 && t3.indexOf(`%`) === -1 && t3.indexOf(`+`) === -1) {
    let n3 = e4.indexOf(`?`, 8);
    if (n3 === -1) return;
    for (e4.startsWith(t3, n3 + 1) || (n3 = e4.indexOf(`&${t3}`, n3 + 1)); n3 !== -1; ) {
      let r3 = e4.charCodeAt(n3 + t3.length + 1);
      if (r3 === 61) {
        let r4 = n3 + t3.length + 2, i3 = e4.indexOf(`&`, r4);
        return S(e4.slice(r4, i3 === -1 ? void 0 : i3));
      }
      if (r3 == 38 || isNaN(r3)) return ``;
      n3 = e4.indexOf(`&${t3}`, n3 + 1);
    }
    if (i2 = /[%+]/.test(e4), !i2) return;
  }
  let a2 = /* @__PURE__ */ Object.create(null);
  i2 ??= /[%+]/.test(e4);
  let o2 = e4.indexOf(`?`, 8);
  for (; o2 !== -1; ) {
    let t4 = e4.indexOf(`&`, o2 + 1), r3 = e4.indexOf(`=`, o2);
    r3 > t4 && t4 !== -1 && (r3 = -1);
    let s2 = e4.slice(o2 + 1, r3 === -1 ? t4 === -1 ? void 0 : t4 : r3);
    if (i2 && (s2 = S(s2)), o2 = t4, s2 === ``) continue;
    let c2;
    r3 === -1 ? c2 = `` : (c2 = e4.slice(r3 + 1, t4 === -1 ? void 0 : t4), i2 && (c2 = S(c2))), n2 ? (a2[s2] && Array.isArray(a2[s2]) || (a2[s2] = []), a2[s2].push(c2)) : a2[s2] ??= c2;
  }
  return t3 ? a2[t3] : a2;
}, "re");
var ie = re;
var ae = /* @__PURE__ */ __name((e4, t3) => re(e4, t3, true), "ae");
var oe = decodeURIComponent;
var se = class {
  static {
    __name(this, "se");
  }
  raw;
  #e;
  #t;
  routeIndex = 0;
  path;
  bodyCache = {};
  constructor(e4, t3 = `/`, n2 = [[]]) {
    this.raw = e4, this.path = t3, this.#t = n2;
  }
  param(e4) {
    return e4 ? this.#n(e4) : this.#r();
  }
  #n(e4) {
    let t3 = this.#t[0][this.routeIndex]?.[1][e4], n2 = this.#i(t3);
    return n2 && x(n2);
  }
  #r() {
    let e4 = {}, t3 = Object.keys(this.#t[0][this.routeIndex]?.[1] ?? {});
    for (let n2 of t3) {
      let t4 = this.#i(this.#t[0][this.routeIndex][1][n2]);
      t4 !== void 0 && (e4[n2] = x(t4));
    }
    return e4;
  }
  #i(e4) {
    return this.#t[1] ? this.#t[1][e4] : e4;
  }
  query(e4) {
    return ie(this.url, e4);
  }
  queries(e4) {
    return ae(this.url, e4);
  }
  header(e4) {
    if (e4) return this.raw.headers.get(e4) ?? void 0;
    let t3 = /* @__PURE__ */ Object.create(null);
    return this.raw.headers.forEach((e5, n2) => {
      t3[n2] = e5;
    }), t3;
  }
  async parseBody(e4) {
    return o(this, e4);
  }
  #a = /* @__PURE__ */ __name((e4) => {
    let { bodyCache: t3, raw: n2 } = this, r2 = t3[e4];
    if (r2) return r2;
    for (let n3 in t3) return t3[n3].then((t4) => (n3 === `json` && (t4 = JSON.stringify(t4)), new Response(t4)[e4]()));
    return t3[e4] = n2[e4]();
  }, "#a");
  json() {
    return this.#a(`text`).then((e4) => JSON.parse(e4));
  }
  text() {
    return this.#a(`text`);
  }
  arrayBuffer() {
    return this.#a(`arrayBuffer`);
  }
  bytes() {
    return this.#a(`arrayBuffer`).then((e4) => new Uint8Array(e4));
  }
  blob() {
    return this.#a(`blob`);
  }
  formData() {
    return this.#a(`formData`);
  }
  addValidatedData(e4, t3) {
    (this.#e ??= {})[e4] = t3;
  }
  valid(e4) {
    return this.#e?.[e4];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [t]() {
    return this.#t;
  }
  get matchedRoutes() {
    return this.#t[0].map(([[, e4]]) => e4);
  }
  get routePath() {
    return this.#t[0].map(([[, e4]]) => e4)[this.routeIndex].path;
  }
};
var ce = { Stringify: 1, BeforeStream: 2, Stream: 3 };
var le = /* @__PURE__ */ __name((e4, t3) => {
  let n2 = new String(e4);
  return n2.isEscaped = true, n2.callbacks = t3, n2;
}, "le");
var C = /* @__PURE__ */ __name(async (e4, t3, n2, r2, i2) => {
  typeof e4 == `object` && !(e4 instanceof String) && (e4 instanceof Promise || (e4 = e4.toString()), e4 instanceof Promise && (e4 = await e4));
  let a2 = e4.callbacks;
  if (!a2?.length) return Promise.resolve(e4);
  i2 ? i2[0] += e4 : i2 = [e4];
  let o2 = Promise.all(a2.map((e5) => e5({ phase: t3, buffer: i2, context: r2 }))).then((e5) => Promise.all(e5.filter(Boolean).map((e6) => C(e6, t3, false, r2, i2))).then(() => i2[0]));
  return n2 ? le(await o2, a2) : o2;
}, "C");
var ue = `text/plain; charset=UTF-8`;
var w = /* @__PURE__ */ __name((e4, t3) => ({ "Content-Type": e4, ...t3 }), "w");
var T = /* @__PURE__ */ __name((e4, t3) => new Response(e4, t3), "T");
var de = class {
  static {
    __name(this, "de");
  }
  #e;
  #t;
  env = {};
  #n;
  finalized = false;
  error;
  #r;
  #i;
  #a;
  #o;
  #s;
  #c;
  #l;
  #u;
  #d;
  constructor(e4, t3) {
    this.#e = e4, t3 && (this.#i = t3.executionCtx, this.env = t3.env, this.#c = t3.notFoundHandler, this.#d = t3.path, this.#u = t3.matchResult);
  }
  get req() {
    return this.#t ??= new se(this.#e, this.#d, this.#u), this.#t;
  }
  get event() {
    if (this.#i && `respondWith` in this.#i) return this.#i;
    throw Error(`This context has no FetchEvent`);
  }
  get executionCtx() {
    if (this.#i) return this.#i;
    throw Error(`This context has no ExecutionContext`);
  }
  get res() {
    return this.#a ||= T(null, { headers: this.#l ??= new Headers() });
  }
  set res(e4) {
    if (this.#a && e4) {
      e4 = T(e4.body, e4);
      for (let [t3, n2] of this.#a.headers.entries()) if (t3 !== `content-type`) {
        if (t3 === `set-cookie`) {
          let t4 = this.#a.headers.getSetCookie();
          e4.headers.delete(`set-cookie`);
          for (let n3 of t4) e4.headers.append(`set-cookie`, n3);
        } else e4.headers.set(t3, n2);
      }
    }
    this.#a = e4, this.finalized = true;
  }
  render = /* @__PURE__ */ __name((...e4) => (this.#s ??= (e5) => this.html(e5), this.#s(...e4)), "render");
  setLayout = /* @__PURE__ */ __name((e4) => this.#o = e4, "setLayout");
  getLayout = /* @__PURE__ */ __name(() => this.#o, "getLayout");
  setRenderer = /* @__PURE__ */ __name((e4) => {
    this.#s = e4;
  }, "setRenderer");
  header = /* @__PURE__ */ __name((e4, t3, n2) => {
    this.finalized && (this.#a = T(this.#a.body, this.#a));
    let r2 = this.#a ? this.#a.headers : this.#l ??= new Headers();
    t3 === void 0 ? r2.delete(e4) : n2?.append ? r2.append(e4, t3) : r2.set(e4, t3);
  }, "header");
  status = /* @__PURE__ */ __name((e4) => {
    this.#r = e4;
  }, "status");
  set = /* @__PURE__ */ __name((e4, t3) => {
    this.#n ??= /* @__PURE__ */ new Map(), this.#n.set(e4, t3);
  }, "set");
  get = /* @__PURE__ */ __name((e4) => this.#n ? this.#n.get(e4) : void 0, "get");
  get var() {
    return this.#n ? Object.fromEntries(this.#n) : {};
  }
  #f(e4, t3, n2) {
    let r2 = this.#a ? new Headers(this.#a.headers) : this.#l;
    if (typeof t3 == `object` && t3.headers) {
      r2 ??= new Headers();
      for (let [e5, n3] of new Headers(t3.headers)) e5 === `set-cookie` ? r2.append(e5, n3) : r2.set(e5, n3);
    }
    if (n2) {
      if (!r2) {
        let e5 = 0;
        for (let t4 in n2) if (++e5 > 1 || typeof n2[t4] != `string`) {
          r2 = new Headers();
          break;
        }
      }
      if (r2) for (let e5 in n2) {
        let t4 = n2[e5];
        if (typeof t4 == `string`) r2.set(e5, t4);
        else {
          r2.delete(e5);
          for (let n3 of t4) r2.append(e5, n3);
        }
      }
    }
    return T(e4, { status: typeof t3 == `number` ? t3 : t3?.status ?? this.#r, headers: r2 ?? n2 });
  }
  newResponse = /* @__PURE__ */ __name((...e4) => this.#f(...e4), "newResponse");
  body = /* @__PURE__ */ __name((e4, t3, n2) => this.#f(e4, t3, n2), "body");
  text = /* @__PURE__ */ __name((e4, t3, n2) => !this.#l && !this.#r && !t3 && !n2 && !this.finalized ? new Response(e4) : this.#f(e4, t3, w(ue, n2)), "text");
  json = /* @__PURE__ */ __name((e4, t3, n2) => this.#f(JSON.stringify(e4), t3, w(`application/json`, n2)), "json");
  html = /* @__PURE__ */ __name((e4, t3, n2) => {
    let r2 = /* @__PURE__ */ __name((e5) => this.#f(e5, t3, w(`text/html; charset=UTF-8`, n2)), "r");
    return typeof e4 == `object` ? C(e4, ce.Stringify, false, {}).then(r2) : r2(e4);
  }, "html");
  redirect = /* @__PURE__ */ __name((e4, t3) => {
    let n2 = String(e4);
    return this.header(`Location`, /[^\x00-\xFF]/.test(n2) ? encodeURI(n2) : n2), this.newResponse(null, t3 ?? 302);
  }, "redirect");
  notFound = /* @__PURE__ */ __name(() => (this.#c ??= () => T(), this.#c(this)), "notFound");
};
var fe = [`get`, `post`, `put`, `delete`, `options`, `patch`, `query`];
var E = `Can not add a route since the matcher is already built.`;
var D = class extends Error {
  static {
    __name(this, "D");
  }
};
var pe = `__COMPOSED_HANDLER`;
var me = /* @__PURE__ */ __name((e4) => e4.text(`404 Not Found`, 404), "me");
var O = /* @__PURE__ */ __name((e4, t3) => {
  if (`getResponse` in e4) {
    let n2 = e4.getResponse();
    return t3.newResponse(n2.body, n2);
  }
  return console.error(e4), t3.text(`Internal Server Error`, 500);
}, "O");
var he = class t2 {
  static {
    __name(this, "t");
  }
  get;
  post;
  put;
  delete;
  options;
  patch;
  query;
  all;
  on;
  use;
  router;
  getPath;
  _basePath = `/`;
  #e = `/`;
  routes = [];
  constructor(e4 = {}) {
    [...fe, `all`].forEach((e5) => {
      this[e5] = (t4, ...n3) => (typeof t4 == `string` ? this.#e = t4 : this.#r(e5, this.#e, t4), n3.forEach((t5) => {
        this.#r(e5, this.#e, t5);
      }), this);
    }), this.on = (e5, t4, ...n3) => {
      for (let r2 of [t4].flat()) {
        this.#e = r2;
        for (let t5 of [e5].flat()) n3.map((e6) => {
          this.#r(t5.toUpperCase(), this.#e, e6);
        });
      }
      return this;
    }, this.use = (e5, ...t4) => (typeof e5 == `string` ? this.#e = e5 : (this.#e = `*`, t4.unshift(e5)), t4.forEach((e6) => {
      this.#r(`ALL`, this.#e, e6);
    }), this);
    let { strict: t3, ...n2 } = e4;
    Object.assign(this, n2), this.getPath = t3 ?? true ? e4.getPath ?? v : ne;
  }
  #t() {
    let e4 = new t2({ router: this.router, getPath: this.getPath });
    return e4.errorHandler = this.errorHandler, e4.#n = this.#n, e4.routes = this.routes, e4;
  }
  #n = me;
  errorHandler = O;
  route(t3, n2) {
    let r2 = this.basePath(t3);
    return n2.routes.map((t4) => {
      let i2;
      n2.errorHandler === O ? i2 = t4.handler : (i2 = /* @__PURE__ */ __name(async (r3, i3) => (await e([], n2.errorHandler)(r3, () => t4.handler(r3, i3))).res, "i"), i2[pe] = t4.handler), r2.#r(t4.method, t4.path, i2, t4.basePath);
    }), this;
  }
  basePath(e4) {
    let t3 = this.#t();
    return t3._basePath = y(this._basePath, e4), t3;
  }
  onError = /* @__PURE__ */ __name((e4) => (this.errorHandler = e4, this), "onError");
  notFound = /* @__PURE__ */ __name((e4) => (this.#n = e4, this), "notFound");
  mount(e4, t3, n2) {
    let r2, i2;
    n2 && (typeof n2 == `function` ? i2 = n2 : (i2 = n2.optionHandler, r2 = n2.replaceRequest === false ? (e5) => e5 : n2.replaceRequest));
    let a2 = i2 ? (e5) => {
      let t4 = i2(e5);
      return Array.isArray(t4) ? t4 : [t4];
    } : (e5) => {
      let t4;
      try {
        t4 = e5.executionCtx;
      } catch {
      }
      return [e5.env, t4];
    };
    return r2 ||= (() => {
      let t4 = y(this._basePath, e4), n3 = t4 === `/` ? 0 : t4.length;
      return (e5) => {
        let t5 = new URL(e5.url);
        return t5.pathname = this.getPath(e5).slice(n3) || `/`, new Request(t5, e5);
      };
    })(), this.#r(`ALL`, y(e4, `*`), async (e5, n3) => {
      let i3 = await t3(r2(e5.req.raw), ...a2(e5));
      if (i3) return i3;
      await n3();
    }), this;
  }
  #r(e4, t3, n2, r2) {
    e4 = e4.toUpperCase(), t3 = y(this._basePath, t3);
    let i2 = { basePath: r2 === void 0 ? this._basePath : y(this._basePath, r2), path: t3, method: e4, handler: n2 };
    this.router.add(e4, t3, [n2, i2]), this.routes.push(i2);
  }
  #i(e4, t3) {
    if (e4 instanceof Error) return this.errorHandler(e4, t3);
    throw e4;
  }
  #a(t3, n2, r2, i2) {
    if (i2 === `HEAD`) return (async () => new Response(null, await this.#a(t3, n2, r2, `GET`)))();
    let a2 = this.getPath(t3, { env: r2 }), o2 = this.router.match(i2, a2), s2 = new de(t3, { path: a2, matchResult: o2, env: r2, executionCtx: n2, notFoundHandler: this.#n });
    if (o2[0].length === 1) {
      let e4;
      try {
        e4 = o2[0][0][0][0](s2, async () => {
          s2.res = await this.#n(s2);
        });
      } catch (e5) {
        return this.#i(e5, s2);
      }
      return e4 instanceof Promise ? e4.then((e5) => e5 || (s2.finalized ? s2.res : this.#n(s2))).catch((e5) => this.#i(e5, s2)) : e4 ?? this.#n(s2);
    }
    let c2 = e(o2[0], this.errorHandler, this.#n);
    return (async () => {
      try {
        let e4 = await c2(s2);
        if (!e4.finalized) throw Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
        return e4.res;
      } catch (e4) {
        return this.#i(e4, s2);
      }
    })();
  }
  fetch = /* @__PURE__ */ __name((e4, ...t3) => this.#a(e4, t3[1], t3[0], e4.method), "fetch");
  request = /* @__PURE__ */ __name((e4, t3, n2, r2) => e4 instanceof Request ? this.fetch(t3 ? new Request(e4, t3) : e4, n2, r2) : (e4 = e4.toString(), this.fetch(new Request(/^https?:\/\//.test(e4) ? e4 : `http://localhost${y(`/`, e4)}`, t3), n2, r2)), "request");
  fire = /* @__PURE__ */ __name(() => {
    addEventListener(`fetch`, (e4) => {
      e4.respondWith(this.#a(e4.request, e4, void 0, e4.request.method));
    });
  }, "fire");
};
var k = /* @__PURE__ */ __name(() => /* @__PURE__ */ Object.create(null), "k");
var A = [];
function ge(e4, t3) {
  let n2 = this.buildAllMatchers(), r2 = /* @__PURE__ */ __name(((e5, t4) => {
    let r3 = n2[e5] || n2.ALL, i2 = r3[2][t4];
    if (i2) return i2;
    let a2 = t4.match(r3[0]);
    if (!a2) return [[], A];
    let o2 = a2.indexOf(``, 1);
    return [r3[1][o2], a2];
  }), "r");
  return this.match = r2, r2(e4, t3);
}
__name(ge, "ge");
var _e = `[^/]+`;
var ve = `(?:|/.*)`;
var j = /* @__PURE__ */ Symbol();
var ye = new Set(`.\\+*[^]$()`);
function be(e4, t3) {
  return e4.length === 1 ? t3.length === 1 ? e4 < t3 ? -1 : 1 : -1 : t3.length === 1 ? 1 : e4 === `.*` || e4 === `(?:|/.*)` ? t3 === `(?:|/.*)` ? -1 : 1 : t3 === `.*` || t3 === `(?:|/.*)` ? -1 : e4 === `[^/]+` ? 1 : t3 === `[^/]+` ? -1 : e4.length === t3.length ? e4 < t3 ? -1 : 1 : t3.length - e4.length;
}
__name(be, "be");
var xe = class e2 {
  static {
    __name(this, "e");
  }
  #e;
  #t;
  #n = k();
  insert(t3, n2, r2, i2, a2) {
    let o2 = this;
    for (let n3 = 0, a3 = t3.length; n3 < a3; n3++) {
      let s2 = t3[n3], c2 = s2.length === 1 ? s2 === `*` ? n3 === a3 - 1 ? [``, ``, `.*`] : [``, ``, _e] : null : s2 === `/*` ? [``, ``, ve] : s2.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/), l2;
      if (c2) {
        let t4 = c2[1], n4 = c2[2] || `[^/]+`;
        if (t4 && c2[2] && (n4 === `.*` || (n4 = n4.replace(/^\((?!\?:)(?=[^)]+\)$)/, `(?:`), /\((?!\?:)/.test(n4)) || n4.length === 1 && ye.has(n4))) throw j;
        if (l2 = o2.#n[n4], !l2) {
          if (n4 !== `.*` && n4 !== `(?:|/.*)`) {
            for (let e4 in o2.#n) if ((n4.length > 1 || e4.length > 1) && e4 !== `.*` && e4 !== `(?:|/.*)`) throw j;
          }
          l2 = o2.#n[n4] = new e2();
        }
        t4 !== `` && (l2.#t ??= i2.varIndex++, r2.push([t4, l2.#t]));
      } else if (l2 = o2.#n[s2], !l2) {
        for (let e4 in o2.#n) if (e4.length > 1 && e4 !== `.*` && e4 !== `(?:|/.*)`) throw j;
        l2 = o2.#n[s2] = new e2();
      }
      o2 = l2;
    }
    if (o2.#e !== void 0) throw j;
    o2.#e = a2 ? -1 : n2;
  }
  buildRegExpStr() {
    let e4 = Object.keys(this.#n).sort(be).map((e5) => {
      let t3 = this.#n[e5], n2 = t3.buildRegExpStr();
      return n2 === `` ? `` : (typeof t3.#t == `number` ? `(${e5})@${t3.#t}` : ye.has(e5) ? `\\${e5}` : e5) + n2;
    }).filter(Boolean);
    return typeof this.#e == `number` && this.#e !== -1 && e4.unshift(`#${this.#e}`), e4.length === 0 ? `` : e4.length === 1 ? e4[0] : `(?:` + e4.join(`|`) + `)`;
  }
};
var M = class {
  static {
    __name(this, "M");
  }
  #e = { varIndex: 0 };
  #t = new xe();
  #n = 0;
  paths = k();
  insert(e4, t3) {
    if (t3) {
      this.#t.insert(e4.split(``), 0, [], this.#e, true);
      return;
    }
    let n2 = [], r2 = [], i2 = e4;
    for (let e5 = 0; ; ) {
      let t4 = false;
      if (i2 = i2.replace(/\{[^}]+\}/g, (n3) => {
        let i3 = `@\\${e5}`;
        return r2[e5] = [i3, n3], e5++, t4 = true, i3;
      }), !t4) break;
    }
    let a2 = i2.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let e5 = r2.length - 1; e5 >= 0; e5--) {
      let [t4] = r2[e5];
      for (let n3 = a2.length - 1; n3 >= 0; n3--) if (a2[n3].indexOf(t4) !== -1) {
        a2[n3] = a2[n3].replace(t4, r2[e5][1]);
        break;
      }
    }
    this.#t.insert(a2, this.#n, n2, this.#e, false), this.paths[e4] = [this.#n++, n2];
  }
  buildRegExp() {
    let e4 = this.#t.buildRegExpStr();
    if (e4 === ``) return [/^$/, [], []];
    let t3 = 0, n2 = [], r2 = [];
    return e4 = e4.replace(/#(\d+)|@(\d+)|\.\*\$/g, (e5, i2, a2) => i2 === void 0 ? (a2 === void 0 || (r2[Number(a2)] = ++t3), ``) : (n2[++t3] = Number(i2), `$()`)), [RegExp(`^${e4}`), n2, r2];
  }
};
var N = k();
function P(e4) {
  return N[e4] ??= RegExp(`^${e4.replace(/\/:[^/{}]+(?:\{\[\^\/]\+})?(?=[/{]|$)|\/?\*$|([.\\+*[^\]$()?{}|])/g, (e5, t3) => t3 ? `\\${t3}` : e5 === `/*` ? ve : e5 === `*` ? `.*` : `/:${_e}`)}$`);
}
__name(P, "P");
function F(e4, t3) {
  for (let n2 of Object.keys(e4).sort((e5, t4) => t4.length - e5.length)) if (P(n2).test(t3)) return [...e4[n2]];
}
__name(F, "F");
var Se = class {
  static {
    __name(this, "Se");
  }
  name = `RegExpRouter`;
  #e;
  #t;
  #n;
  constructor() {
    this.#e = { ALL: k() }, this.#t = { ALL: k() }, this.#n = { ALL: new M() };
  }
  #r(e4, t3) {
    try {
      this.#n[e4].insert(t3, !/\*|\/:/.test(t3));
    } catch (e5) {
      throw e5 === j ? new D(t3) : e5;
    }
  }
  add(e4, t3, n2) {
    let r2 = this.#e, i2 = this.#t;
    if (!r2) throw Error(E);
    if (!r2[e4]) {
      this.#n[e4] = new M();
      for (let t4 of [r2, i2]) {
        t4[e4] = k();
        for (let n3 in t4.ALL) t4[e4][n3] = [...t4.ALL[n3]], this.#r(e4, n3);
      }
    }
    t3 === `/*` && (t3 = `*`);
    let a2 = e4 === `ALL` ? Object.keys(r2) : [e4];
    if (/\*$/.test(t3)) {
      let e5 = P(t3);
      for (let e6 of a2) r2[e6][t3] || (this.#r(e6, t3), r2[e6][t3] = F(r2[e6], t3) || F(r2.ALL, t3) || []);
      for (let o3 of [r2, i2]) for (let r3 of a2) for (let i3 in o3[r3]) e5.test(i3) && o3[r3][i3].push([n2, t3]);
      return;
    }
    let o2 = b(t3) || [t3];
    for (let e5 of o2) for (let t4 of a2) i2[t4][e5] || (this.#r(t4, e5), i2[t4][e5] = F(r2[t4], e5) || F(r2.ALL, e5) || []), i2[t4][e5].push([n2, e5]);
  }
  match = ge;
  buildAllMatchers() {
    let e4 = k();
    for (let t3 of Object.keys(this.#t)) e4[t3] = this.#i(t3);
    return this.#e = this.#t = this.#n = void 0, N = k(), e4;
  }
  #i(e4) {
    let t3 = this.#e[e4], n2 = this.#t[e4], r2 = this.#n[e4], i2 = k(), a2 = [], [o2, s2, c2] = r2.buildRegExp();
    for (let e5 of [t3, n2]) for (let t4 in e5) {
      let n3 = e5[t4], o3 = r2.paths[t4];
      if (!o3) {
        i2[t4] = [n3.map(([e6]) => [e6, k()]), A];
        continue;
      }
      a2[o3[0]] = n3.map(([e6, t5]) => [e6, r2.paths[t5][1].reduceRight((e7, [t6], n4) => (e7[t6] = c2[o3[1][n4][1]], e7), k())]);
    }
    return [o2, s2.map((e5) => a2[e5]), i2];
  }
};
var Ce = class {
  static {
    __name(this, "Ce");
  }
  name = `SmartRouter`;
  #e = [];
  #t = [];
  constructor(e4) {
    this.#e = e4.routers;
  }
  add(e4, t3, n2) {
    if (!this.#t) throw Error(E);
    this.#t.push([e4, t3, n2]);
  }
  match(e4, t3) {
    if (!this.#t) throw Error(`Fatal error`);
    let n2 = this.#e, r2 = this.#t, i2 = n2.length, a2 = 0, o2;
    for (; a2 < i2; a2++) {
      let i3 = n2[a2];
      try {
        for (let e5 = 0, t4 = r2.length; e5 < t4; e5++) i3.add(...r2[e5]);
        o2 = i3.match(e4, t3);
      } catch (e5) {
        if (e5 instanceof D) continue;
        throw e5;
      }
      this.match = i3.match.bind(i3), this.#e = [i3], this.#t = void 0;
      break;
    }
    if (a2 === i2) throw Error(`Fatal error`);
    return this.name = `SmartRouter + ${this.activeRouter.name}`, o2;
  }
  get activeRouter() {
    if (this.#t || this.#e.length !== 1) throw Error(`No active router has been determined yet.`);
    return this.#e[0];
  }
};
var I = k();
var we = 0;
var Te = class e3 {
  static {
    __name(this, "e");
  }
  #e = [];
  #t = k();
  #n = [];
  #r;
  #i = I;
  insert(t3, n2, r2) {
    let i2 = this, a2 = p(n2), o2 = /* @__PURE__ */ new Set(), s2 = 0;
    for (let t4 of a2) {
      let n3 = a2[++s2], r3 = ee(t4, n3) || (n3 === void 0 && t4 && t4.indexOf(`*`) === t4.length - 1 ? t4 : null), c2 = Array.isArray(r3), l2 = c2 ? r3[0] : r3 || t4, u2 = i2.#t[l2] ||= new e3();
      r3 && !u2.#r && (u2.#r = r3, i2.#n.push(u2)), i2 = u2, c2 && o2.add(r3[1]);
    }
    i2.#e.push({ [t3]: { handler: r2, possibleKeys: [...o2], score: ++we } });
  }
  #a(e4, t3, n2, r2, i2) {
    for (let a2 = 0, o2 = t3.#e.length; a2 < o2; a2++) {
      let o3 = t3.#e[a2], s2 = o3[n2] || o3.ALL;
      if (s2) {
        s2.params = k(), e4.push(s2);
        for (let e5 = 0, t4 = s2.possibleKeys.length; e5 < t4; e5++) {
          let t5 = s2.possibleKeys[e5];
          s2.params[t5] = i2?.[t5] && !e5 ? i2[t5] : r2[t5] ?? i2?.[t5];
        }
      }
    }
  }
  search(e4, t3) {
    let n2 = [];
    this.#i = I;
    let r2 = [this], i2 = f(t3), a2 = [], o2 = i2.length, s2 = null;
    for (let c2 = 0; c2 < o2; c2++) {
      let l2 = i2[c2], u2 = c2 === o2 - 1, d2 = [];
      for (let f3 = 0, p2 = r2.length; f3 < p2; f3++) {
        let p3 = r2[f3], m2 = p3.#t[l2];
        m2 && (m2.#i = p3.#i, u2 ? (m2.#t[`*`] && this.#a(n2, m2.#t[`*`], e4, p3.#i), this.#a(n2, m2, e4, p3.#i)) : d2.push(m2));
        for (let r3 of p3.#n) {
          let f4 = r3.#r, m3 = p3.#i === I ? {} : { ...p3.#i };
          if (typeof f4 == `string`) {
            (f4 === `*` || l2.startsWith(f4.slice(0, -1))) && (this.#a(n2, r3, e4, p3.#i), f4 === `*` && (r3.#i = m3, d2.push(r3)));
            continue;
          }
          let [, h2, g2] = f4;
          if (!(!l2 && g2 === true)) {
            if (g2 !== true) {
              if (!s2) {
                s2 = [];
                let e5 = +(t3[0] === `/`);
                for (let t4 = 0; t4 < o2; t4++) s2[t4] = e5, e5 += i2[t4].length + 1;
              }
              let l3 = t3.slice(s2[c2]), u3 = g2.exec(l3);
              if (u3) {
                m3[h2] = u3[0], this.#a(n2, r3, e4, p3.#i, m3), u3[0].length === l3.length && r3.#t[`*`] && this.#a(n2, r3.#t[`*`], e4, p3.#i, m3);
                for (let e5 in r3.#t) {
                  r3.#i = m3;
                  let e6 = u3[0].match(/\//g)?.length ?? 0;
                  (a2[e6] ||= []).push(r3);
                  break;
                }
                continue;
              }
            }
            (g2 === true || g2.test(l2)) && (m3[h2] = l2, u2 ? (this.#a(n2, r3, e4, m3, p3.#i), r3.#t[`*`] && this.#a(n2, r3.#t[`*`], e4, m3, p3.#i)) : (r3.#i = m3, d2.push(r3)));
          }
        }
      }
      let f2 = a2.shift();
      r2 = f2 ? d2.concat(f2) : d2;
    }
    return n2[1] && n2.sort((e5, t4) => e5.score - t4.score), [n2.map(({ handler: e5, params: t4 }) => [e5, t4])];
  }
};
var Ee = class {
  static {
    __name(this, "Ee");
  }
  name = `TrieRouter`;
  #e = new Te();
  add(e4, t3, n2) {
    for (let r2 of b(t3) || [t3]) this.#e.insert(e4, r2, n2);
  }
  match(e4, t3) {
    return this.#e.search(e4, t3);
  }
};
var L = class extends he {
  static {
    __name(this, "L");
  }
  constructor(e4 = {}) {
    super(e4), this.router = e4.router ?? new Ce({ routers: [new Se(), new Ee()] });
  }
};
var De = [`development`, `staging`, `production`, `test`];
var Oe = [`debug`, `info`, `warn`, `error`];
var R = class extends Error {
  static {
    __name(this, "R");
  }
  constructor(e4) {
    super(e4), this.name = `ConfigurationError`;
  }
};
function z(e4, t3) {
  if (e4 === void 0 || e4 === ``) return t3;
  if (De.includes(e4)) return e4;
  throw new R(`Unsupported QIMA environment: ${e4}`);
}
__name(z, "z");
function ke(e4) {
  if (e4 === void 0 || e4 === ``) return `info`;
  if (Oe.includes(e4)) return e4;
  throw new R(`Unsupported QIMA log level: ${e4}`);
}
__name(ke, "ke");
function Ae(e4, t3, n2) {
  let r2 = t3 === void 0 || t3 === `` ? n2 : t3;
  try {
    return new URL(r2).toString().replace(/\/$/, ``);
  } catch {
    throw new R(`Invalid URL for ${e4}`);
  }
}
__name(Ae, "Ae");
function B(e4 = {}) {
  let t3 = z(e4.NODE_ENV, `development`), n2 = z(e4.APP_ENV, t3);
  return Object.freeze({ nodeEnv: t3, appEnv: n2, apiBasePath: `/api/v1`, webUrl: Ae(`WEB_URL`, e4.WEB_URL, `http://localhost:3000`), logLevel: ke(e4.LOG_LEVEL), hasAuthSecret: typeof e4.AUTH_SECRET == `string` && e4.AUTH_SECRET.length > 0 });
}
__name(B, "B");
function V(e4) {
  return Object.freeze({ ok: true, data: e4 });
}
__name(V, "V");
function H(e4, t3) {
  return Object.freeze({ ok: false, error: Object.freeze({ code: e4, message: t3 }) });
}
__name(H, "H");
var U = Object.freeze({ VALIDATION_ERROR: 400, UNAUTHENTICATED: 401, FORBIDDEN: 403, NOT_FOUND: 404, CONFLICT: 409, SCOPE_VIOLATION: 403, INTERNAL_ERROR: 500 });
var W = class extends Error {
  static {
    __name(this, "W");
  }
  constructor(e4) {
    super(e4), this.name = `DatabaseQueryError`;
  }
};
async function G(e4, t3, n2 = []) {
  try {
    return await e4.prepare(t3).bind(...n2).first();
  } catch {
    throw new W(`Database query failed.`);
  }
}
__name(G, "G");
async function K(e4, t3, n2 = []) {
  try {
    return (await e4.prepare(t3).bind(...n2).all()).results ?? [];
  } catch {
    throw new W(`Database query failed.`);
  }
}
__name(K, "K");
function je(e4) {
  return { id: e4.id, key: e4.key, name: e4.name, description: e4.description, scopeLevel: e4.scope_level, isSystem: e4.is_system === 1, createdAt: e4.created_at, updatedAt: e4.updated_at };
}
__name(je, "je");
function q(e4) {
  return { id: e4.id, key: e4.key, resource: e4.resource, action: e4.action, description: e4.description, createdAt: e4.created_at };
}
__name(q, "q");
function Me(e4) {
  return { async findByKey(t3) {
    let n2 = await G(e4, `select * from roles where key = ?`, [t3]);
    return n2 === null ? null : je(n2);
  }, async list() {
    return (await K(e4, `select * from roles order by scope_level, key`)).map(je);
  }, async listPermissions(t3) {
    return (await K(e4, `select p.* from permissions p
           join role_permissions rp on rp.permission_id = p.id
          where rp.role_id = ?
          order by p.key`, [t3])).map(q);
  } };
}
__name(Me, "Me");
function Ne(e4) {
  return { async findByKey(t3) {
    let n2 = await G(e4, `select * from permissions where key = ?`, [t3]);
    return n2 === null ? null : q(n2);
  }, async list() {
    return (await K(e4, `select * from permissions order by key`)).map(q);
  } };
}
__name(Ne, "Ne");
var Pe = [`organizations`, `units`, `sites`, `domain_mappings`, `users`, `roles`, `permissions`, `role_permissions`, `user_organization_roles`, `user_unit_roles`, `audit_logs`, `organization_settings`, `unit_settings`];
var Fe = [`idx_organizations_slug`, `idx_units_organization_id`, `idx_units_organization_slug`, `idx_sites_unit_id`, `idx_domain_mappings_domain`, `idx_domain_mappings_site_id`, `idx_users_email`, `idx_roles_key`, `idx_permissions_key`, `idx_role_permissions_role_id`, `idx_role_permissions_permission_id`, `idx_user_organization_roles_user_id`, `idx_user_organization_roles_organization_id`, `idx_user_unit_roles_user_id`, `idx_user_unit_roles_unit_id`, `idx_audit_logs_organization_id`, `idx_audit_logs_unit_id`, `idx_audit_logs_user_id`, `idx_audit_logs_created_at`];
Object.freeze({ units: [`organization_id`], sites: [`unit_id`], domain_mappings: [`site_id`], user_organization_roles: [`user_id`, `organization_id`], user_unit_roles: [`user_id`, `unit_id`], organization_settings: [`organization_id`], unit_settings: [`unit_id`], audit_logs: [`organization_id`, `unit_id`] }), Object.freeze({ sessions: [`user_id`] });
async function Ie(e4) {
  return (await K(e4, `select name from sqlite_master where type = 'table' and name not like 'sqlite_%' and name not like '_cf_%' order by name`)).map((e5) => e5.name);
}
__name(Ie, "Ie");
async function Le(e4) {
  return (await K(e4, `select name from sqlite_master where type = 'index' and name not like 'sqlite_%' order by name`)).map((e5) => e5.name);
}
__name(Le, "Le");
async function Re(e4) {
  return ze(e4, Pe, Fe);
}
__name(Re, "Re");
async function ze(e4, t3, n2) {
  let [r2, i2] = await Promise.all([Ie(e4), Le(e4)]), a2 = new Set(r2), o2 = new Set(i2), s2 = t3.filter((e5) => !a2.has(e5)), c2 = n2.filter((e5) => !o2.has(e5));
  return { complete: s2.length === 0 && c2.length === 0, missingTables: s2, missingIndexes: c2, tableCount: r2.length };
}
__name(ze, "ze");
var J = new L();
function Y(e4) {
  return e4?.DB ?? null;
}
__name(Y, "Y");
J.get(`/schema`, async (e4) => {
  let t3 = Y(e4.env);
  if (t3 === null) return e4.json(H(`INTERNAL_ERROR`, `Database binding is not configured for this environment.`), U.INTERNAL_ERROR);
  try {
    let n2 = await Re(t3);
    return n2.complete ? e4.json(V({ phase: `phase-1-database-foundation`, schema: `complete`, tableCount: n2.tableCount })) : e4.json(H(`INTERNAL_ERROR`, `Phase 1 schema is incomplete. Missing tables: ${n2.missingTables.join(`, `) || `none`}. Missing indexes: ${n2.missingIndexes.join(`, `) || `none`}.`), U.INTERNAL_ERROR);
  } catch {
    return e4.json(H(`INTERNAL_ERROR`, `Schema verification failed.`), U.INTERNAL_ERROR);
  }
}), J.get(`/access-catalog`, async (e4) => {
  let t3 = Y(e4.env);
  if (t3 === null) return e4.json(H(`INTERNAL_ERROR`, `Database binding is not configured for this environment.`), U.INTERNAL_ERROR);
  try {
    let n2 = Me(t3), r2 = Ne(t3), [i2, a2] = await Promise.all([n2.list(), r2.list()]);
    return e4.json(V({ roles: i2.map((e5) => ({ key: e5.key, name: e5.name, scopeLevel: e5.scopeLevel, isSystem: e5.isSystem })), permissions: a2.map((e5) => e5.key) }));
  } catch {
    return e4.json(H(`INTERNAL_ERROR`, `Access catalogue lookup failed.`), U.INTERNAL_ERROR);
  }
});
var Be = `phase-1-database-foundation`;
var X = new L();
X.get(`/health`, (e4) => {
  let t3 = B(e4.env);
  return e4.json(V({ service: `qima-api`, status: `ok`, environment: t3.appEnv, apiVersion: `v1` }));
}), X.get(`/meta`, (e4) => {
  let t3 = B(e4.env);
  return e4.json(V({ service: `qima-api`, phase: Be, apiBasePath: t3.apiBasePath, environment: t3.appEnv, databaseBound: e4.env?.DB !== void 0, authSecretConfigured: t3.hasAuthSecret }));
}), X.get(`/health/database`, async (e4) => {
  if (e4.env?.DB === void 0) return e4.json(H(`INTERNAL_ERROR`, `Database binding is not configured for this environment.`), U.INTERNAL_ERROR);
  try {
    let t3 = await e4.env.DB.prepare(`select 1 as ok`).first();
    return e4.json(V({ database: `reachable`, probe: t3?.ok ?? null }));
  } catch {
    return e4.json(H(`INTERNAL_ERROR`, `Database probe failed.`), U.INTERNAL_ERROR);
  }
}), X.route(`/database`, J), X.all(`*`, (e4) => e4.json(H(`NOT_FOUND`, `API route not found.`), U.NOT_FOUND));
var Ve = { "phase-0-bootstrap": `Phase 0 \u2014 Project Bootstrap`, "phase-1-database-foundation": `Phase 1 \u2014 Database Foundation`, "phase-2-authentication-access": `Phase 2 \u2014 Authentication & Access`, "phase-3-organization-unit": `Phase 3 \u2014 Organization & Unit` };
function He(e4) {
  return Ve[e4] ?? e4;
}
__name(He, "He");
function Z(e4) {
  return e4.replace(/&/g, `&amp;`).replace(/</g, `&lt;`).replace(/>/g, `&gt;`).replace(/"/g, `&quot;`);
}
__name(Z, "Z");
function Ue(e4) {
  let t3 = Z(e4.environment), n2 = Z(e4.apiBasePath), r2 = Z(e4.phase), i2 = Z(He(e4.phase));
  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QIMA \u2014 ${i2}</title>
<link rel="stylesheet" href="/static/tokens.css">
</head>
<body>
<header id="bootstrap-header">
  <p class="label">QIMA Platform</p>
  <h1>${i2}</h1>
  <p class="body-large">
    Fondasi engineering dan skema data QIMA aktif. Modul produk belum
    diimplementasikan pada fase ini.
  </p>
</header>

<main id="bootstrap-main">
  <section id="runtime-status" aria-labelledby="runtime-status-title">
    <h2 id="runtime-status-title">Runtime</h2>
    <dl>
      <dt>Environment</dt>
      <dd id="environment-value">${t3}</dd>
      <dt>API base path</dt>
      <dd id="api-base-path-value">${n2}</dd>
      <dt>Phase</dt>
      <dd id="phase-value">${r2}</dd>
    </dl>
  </section>

  <section id="health-status" aria-labelledby="health-status-title">
    <h2 id="health-status-title">Status API</h2>
    <p id="health-output" class="state-loading" role="status" aria-live="polite">Memeriksa\u2026</p>
  </section>

  <section id="phase-scope" aria-labelledby="phase-scope-title">
    <h2 id="phase-scope-title">Cakupan fase ini</h2>
    <ul>
      <li>Struktur repository &amp; workspace</li>
      <li>Skeleton web &amp; API (<code>${n2}</code>)</li>
      <li>Batas modul domain / shared / config</li>
      <li>Baseline lint, format, type-check, build, test</li>
      <li>Baseline tooling migrasi database</li>
      <li>Skema database: organisasi, unit, site, domain mapping</li>
      <li>Skema akses: user, role, permission, scope assignment</li>
      <li>Skema audit log (append-only) &amp; settings</li>
    </ul>
  </section>
</main>

<footer id="bootstrap-footer">
  <p class="caption">QIMA v0.1.0 \u2014 implementasi mengikuti QIMA Master Traceability Matrix v1.0</p>
</footer>

<script src="/static/bootstrap.js"><\/script>
</body>
</html>`;
}
__name(Ue, "Ue");
var We = new L();
We.get(`/`, (e4) => {
  let t3 = B(e4.env);
  return e4.html(Ue({ environment: t3.appEnv, apiBasePath: t3.apiBasePath, phase: Be }));
});
var Q = new L();
Q.use(`*`, async (e4, t3) => {
  try {
    await t3();
  } catch {
    return e4.json(H(`INTERNAL_ERROR`, `Unexpected server error.`), U.INTERNAL_ERROR);
  }
}), Q.route(`/api/v1`, X), Q.route(`/`, We);
function Ge(e4) {
  let t3 = e4.req.path === `/api` || e4.req.path.startsWith(`/api/`);
  return e4.json(H(`NOT_FOUND`, t3 ? `API route not found.` : `Resource not found.`), U.NOT_FOUND);
}
__name(Ge, "Ge");
Q.all(`*`, Ge), Q.notFound(Ge), Q.onError((e4, t3) => t3.json(H(`INTERNAL_ERROR`, `Unexpected server error.`), U.INTERNAL_ERROR));
var $ = new L();
var Ke = Object.assign({ "/src/index.ts": Q });
var qe = false;
for (let [, e4] of Object.entries(Ke)) e4 && ($.route(`/`, e4), $.notFound(e4.notFoundHandler), qe = true);
if (!qe) throw Error(`Can't import modules from ['/src/index.ts']`);

// ../node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e4) {
      console.error("Failed to drain the unused request body.", e4);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;

// ../node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError(e4) {
  return {
    name: e4?.name,
    message: e4?.message ?? String(e4),
    stack: e4?.stack,
    cause: e4?.cause === void 0 ? void 0 : reduceError(e4.cause)
  };
}
__name(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e4) {
    const error = reduceError(e4);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;

// ../.wrangler/tmp/bundle-agmo6n/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = $;

// ../node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");

// ../.wrangler/tmp/bundle-agmo6n/middleware-loader.entry.ts
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default as default
};
//# sourceMappingURL=bundledWorker-0.6510567293000413.mjs.map
